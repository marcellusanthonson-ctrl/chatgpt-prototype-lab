from __future__ import annotations
import json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
AUTH='AUTHORIZATION_LAB_STATISTICS_COUNTER_EXPERIMENT_SOURCE_ADOPTION_HUMAN_REVIEW_AND_CONDITIONAL_CLOSURE_178'
PKG='CAROLINA-STATISTICS-MOTION-EXPERIMENT-001'
BASE='foundation-library/motion-system/MOTION-SYSTEM-001/source-packages/CAROLINA-STATISTICS-MOTION-EXPERIMENT-001'
AUTH_P='projects/lab/authorizations/AUTHORIZATION_LAB_STATISTICS_COUNTER_EXPERIMENT_SOURCE_ADOPTION_HUMAN_REVIEW_AND_CONDITIONAL_CLOSURE_178.json'
BRIEF_P='projects/lab/briefs/CODEX_STATISTICS_COUNTER_EXPERIMENT_SOURCE_ADOPTION_178_001.json'
EVD_P='projects/lab/evidence/EVD-LAB-STATISTICS-COUNTER-SOURCE-PACKAGE-178.json'
PKG_P=f'{BASE}/SOURCE_PACKAGE_MANIFEST.json'
HTML=f'{BASE}/expanded/statistics-motion-001/CAROLINA_MD_STATISTICS_MOTION_EXPERIMENT_001.html'
DELTA='registry/deltas/statistics-counter-source-package-adoption-178.json'
PEND='projects/lab/pending/PEND-LAB-043.json'
A_SHA='8eecd53dc698d4587dfa882a5eabe701ec9a77a45bb9747d57f0cf5d68c876b0'
H_SHA='74274e55ff1c8b9edd849d433f12bf6ffe0abb00097872feb6bc7adde83b463e'
I_SHA='c44c2a763ca761e3c1be91f122abc90c76669c65c7a960abd81adbd50d2c8115'
STAMP='2026-08-02T22:29:00-04:00'; DATE='2026-08-02'

def load(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
def save(p,o):
    q=ROOT/p; q.parent.mkdir(parents=True,exist_ok=True)
    q.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def add(a,v):
    if v not in a:a.append(v)
def sha(p):
    h=hashlib.sha256()
    with (ROOT/p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def bump(v):
    p=str(v).split('.')
    if len(p)>2 and p[-1].isdigit():p[-1]=str(int(p[-1])+1)
    return '.'.join(p)
def add_auth_state(o):
    if isinstance(o,dict):
        if 'pend_047_exact_canonical_aggregate_reconciliation_and_closure_177' in o:
            o['statistics_counter_experiment_source_adoption_human_review_and_conditional_closure_178']='GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION';return True
        return any(add_auth_state(v) for v in o.values())
    if isinstance(o,list):return any(add_auth_state(v) for v in o)
    return False

assert sha(HTML)==H_SHA and sha(f'{BASE}/ARCHIVE_CONTENT_INDEX.json')==I_SHA
idx=load(f'{BASE}/ARCHIVE_CONTENT_INDEX.json'); assert idx['archive_entry_count']==163 and idx['extracted_file_count']==134

a=load(AUTH_P);a['status']='GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION';a['stage_1']['status']='COMPLETED_ON_VERIFIED_REMOTE_PUBLICATION';a['stage_1']['completed_at']=STAMP;a['stage_2']['triggered']=False;a['authority_effect_while_waiting']='NO_TECHNICAL_WRITE_UNTIL_EXACT_HUMAN_DETERMINATION_TRIGGERS_STAGE_2';save(AUTH_P,a)
b=load(BRIEF_P);b['status']='STAGE_1_COMPLETE_STAGE_2_AWAITING_EXPLICIT_HUMAN_DETERMINATION';b['stage_1_result']='SOURCE_PACKAGE_AND_DIRECT_REVIEW_ARTIFACT_PUBLISHED';b['next_gate']='DIRECT_HUMAN_REVIEW_OF_PRESERVED_PRIMARY_IMPLEMENTATION';save(BRIEF_P,b)

ep='foundation-library/motion-system/MOTION-SYSTEM-001/effects/data/STATISTICS-COUNTER-STATIC-SUFFIX-001/MANIFEST.json';e=load(ep);e.update({'schema_version':'1.1.0','status':'SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING','maximum_authorized_status':'SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING','authorization_ref':AUTH,'canonical_reference_designation':False,'behavior_core_extraction':False,'product_integration_status':'NOT_AUTHORIZED_NOT_PERFORMED'});e['source_package']={'source_package_id':PKG,'manifest':PKG_P,'direct_review_artifact':HTML,'archive_sha256':A_SHA,'primary_html_sha256':H_SHA,'status':'PRESERVED_AWAITING_DIRECT_HUMAN_REVIEW'};save(ep,e)

mp='foundation-library/motion-system/MOTION-SYSTEM-001/MANIFEST.json';m=load(mp);m.update({'version':'0.2.1','status':'FOUNDATION_PUBLISHED_ROADMAP_COMPLETE_STATISTICS_COUNTER_SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING','latest_authorization_ref':AUTH,'maximum_initial_effect_status':'MIXED_ROADMAP_CANONICAL_REFERENCE_AND_BEHAVIOR_CORE_VALIDATED_STATISTICS_COUNTER_SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING'});rec={'source_package_id':PKG,'effect_id':'STATISTICS-COUNTER-STATIC-SUFFIX-001','path':BASE,'status':'PRESERVED_IN_LAB_AWAITING_DIRECT_HUMAN_REVIEW','archive_sha256':A_SHA,'direct_review_artifact':HTML,'canonical_reference_designation':False,'product_integration':False};sp=m.setdefault('source_packages',[]);sp[:]=[x for x in sp if x.get('source_package_id')!=PKG]+[rec]
for r in [AUTH_P,EVD_P,PKG_P,DELTA]:add(m.setdefault('source_refs',[]),r)
m['remaining_gates']=['STATISTICS_COUNTER_DIRECT_HUMAN_REVIEW_OF_PRESERVED_SOURCE','SEPARATE_NEUTRAL_ADAPTATION_AUTHORIZATION_IF_DESIRED','SEPARATE_REUSABLE_PROMOTION_AUTHORIZATION','SEPARATE_PRODUCT_INTEGRATION_AUTHORIZATION','REMAINING_LIBRARY_POPULATION_IN_BOUNDED_BATCHES'];save(mp,m)

rp='foundation-library/motion-system/MOTION-SYSTEM-001/MOTION_EFFECTS_REGISTRY.json';r=load(rp);r['schema_version']='1.2.0';r['updated_at']=DATE
for x in r['records']:
    if x.get('effect_id')=='STATISTICS-COUNTER-STATIC-SUFFIX-001':x.update({'status':'SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING','source_package':PKG_P,'direct_review_artifact':HTML,'canonical_reference_designated':False,'behavior_core_extracted':False,'reusable_promotion':False,'product_integration':False});break
else:raise AssertionError('missing counter registry record')
save(rp,r)

p=load(PEND);p['status']='STATISTICS_COUNTER_SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING'
for x in ['PRESERVE_STATISTICS_COUNTER_COMPLETE_SOURCE_PACKAGE_IN_LAB','PUBLISH_STATISTICS_COUNTER_DIRECT_REVIEW_ARTIFACT']:add(p.setdefault('completed_actions',[]),x)
p['required_actions']=['HUMAN_REVIEW_PRESERVED_STATISTICS_COUNTER_PRIMARY_IMPLEMENTATION','SEPARATELY_AUTHORIZE_NEUTRAL_ADAPTATION_IF_DESIRED','PROMOTE_REVISE_OR_REJECT_OTHER_INITIAL_EFFECTS','IMPLEMENT_INDUSTRY_EFFECTS_IN_BOUNDED_BATCHES','AUTHORIZE_REUSABLE_PROMOTION_SEPARATELY','AUTHORIZE_PROJECT_INTEGRATIONS_SEPARATELY']
p['statistics_counter']={'effect_id':'STATISTICS-COUNTER-STATIC-SUFFIX-001','status':'SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING','source_package_id':PKG,'source_package_manifest':PKG_P,'direct_review_artifact':HTML,'archive_sha256':A_SHA,'primary_html_sha256':H_SHA,'next_single_gate':'DIRECT_HUMAN_REVIEW_OF_PRESERVED_PRIMARY_IMPLEMENTATION'};p['current_authority']='AUTHORIZATION_178_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_EXPLICIT_HUMAN_DETERMINATION'
for x in [AUTH_P,EVD_P,PKG_P,DELTA]:add(p.setdefault('source_refs',[]),x)
save(PEND,p)
pa='projects/lab/PENDING.json';q=load(pa)
for i,x in enumerate(q['records']):
    if x.get('id')=='PEND-LAB-043':q['records'][i]=p;break
else:raise AssertionError('missing PEND-LAB-043 aggregate')
q['updated_at']=DATE;save(pa,q)

cs='CURRENT_STATE.json';s=load(cs);s['version']=bump(s['version']);s['updated_at']=DATE;cm=s.setdefault('canonical_model',{});cm['motion_statistics_counter_source_package_178']=PKG_P;cm['motion_statistics_counter_authorization_178']=AUTH_P;cm['motion_statistics_counter_evidence_178']=EVD_P;ms=cm['motion_system_foundation'];ms['status']='ROADMAP_COMPLETE_STATISTICS_COUNTER_SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING';ms['latest_authorization']=AUTH;ms['statistics_counter_001']={'effect_id':'STATISTICS-COUNTER-STATIC-SUFFIX-001','status':'SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING','source_package_id':PKG,'source_package_manifest':PKG_P,'archive_sha256':A_SHA,'direct_review_artifact':HTML,'primary_html_sha256':H_SHA,'canonical_reference_designation':False,'behavior_core_extraction':False,'product_integration':False};ms['next_gate']='DIRECT_HUMAN_REVIEW_OF_PRESERVED_STATISTICS_COUNTER_SOURCE';add_auth_state(s);s['next_authorized_action']='AUTHORIZATION_178_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_EXPLICIT_HUMAN_DETERMINATION';s['next_recommended_transition']='DIRECT_HUMAN_REVIEW_OF_PRESERVED_STATISTICS_COUNTER_PRIMARY_IMPLEMENTATION';s['motion_statistics_counter_source_adoption_178']={'authorization':AUTH,'authorization_status':'GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION','source_package_id':PKG,'source_package_status':'PRESERVED_IN_LAB_AWAITING_DIRECT_HUMAN_REVIEW','archive_sha256':A_SHA,'primary_html_sha256':H_SHA,'stage_2_triggered':False,'official_landing_integration':'NOT_AUTHORIZED_NOT_PERFORMED','runtime_effect':'NONE','product_effect':'NONE'};save(cs,s)

psp='projects/lab/PROJECT_STATE.json';ps=load(psp);ps['updated_at']=DATE
for x in [AUTH_P,BRIEF_P,EVD_P,PKG_P,DELTA]:add(ps.setdefault('source_refs',[]),x)
ps['motion_statistics_counter_source_adoption_178']={'authorization_status':'GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION','source_package_id':PKG,'source_package_manifest':PKG_P,'effect_status':'SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING','next_gate':'DIRECT_HUMAN_REVIEW_OF_PRESERVED_PRIMARY_IMPLEMENTATION'};save(psp,ps)

rip='registry/index.json';ri=load(rip);ri['updated_at']=DATE;c=ri['counts'];c['authorizations']=max(c.get('authorizations',0),102);c['evidence']=max(c.get('evidence',0),84);c['source_packages']=max(c.get('source_packages',0),3);regs=ri['registries']
for k in ['authorization_deltas','evidence_deltas','current_state_deltas']:add(regs.setdefault(k,[]),DELTA)
add(regs.setdefault('source_package_records',[]),PKG_P);save(rip,ri)

cp='projects/lab/continuity/CURRENT_CONTINUITY.json';co=load(cp);co['continuity_id']='LAB-CONTINUITY-STATISTICS-COUNTER-SOURCE-PACKAGE-178-20260802';co['status']='STATISTICS_COUNTER_SOURCE_PACKAGE_PRESERVED_DIRECT_HUMAN_REVIEW_PENDING_PRIORITY_INTEGRATIONS_PHASE_1_PRESERVED';co['created_at']=STAMP;co['global_state']['active_execution_authority']='AUTHORIZATION_178_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_EXPLICIT_HUMAN_DETERMINATION';co['authorization_178']={'id':AUTH,'status':'GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION','stage_1':'SOURCE_PACKAGE_PUBLISHED','stage_2':'AWAITING_EXPLICIT_HUMAN_DETERMINATION','triggered':False};co['statistics_counter_source_package']={'source_package_id':PKG,'status':'PRESERVED_IN_LAB_AWAITING_DIRECT_HUMAN_REVIEW','manifest':PKG_P,'archive_sha256':A_SHA,'direct_review_artifact':HTML,'primary_html_sha256':H_SHA};co['next_action']={'single':'DIRECT_HUMAN_REVIEW_OF_PRESERVED_STATISTICS_COUNTER_PRIMARY_IMPLEMENTATION','repository_write_before_human_determination':False};co['authority_effect']='ONLY_CONDITIONAL_STAGE_2_AFTER_EXACT_HUMAN_DETERMINATION'
for x in [AUTH_P,BRIEF_P,EVD_P,PKG_P,DELTA,PEND]:add(co.setdefault('required_reading_order',[]),x)
save(cp,co)
(ROOT/'projects/lab/continuity/CURRENT_CONTINUITY.md').write_text(f'''# Continuidad LAB — paquete fuente completo del contador preservado\n\nLa autorización `{AUTH}` publicó Stage 1. El paquete completo `statistics-motion-001` quedó preservado como `{PKG}`.\n\nRevisión directa: `{HTML}`\n\nRAR: 163 entradas, 134 archivos, SHA-256 `{A_SHA}`. HTML principal SHA-256 `{H_SHA}`.\n\nEl contador permanece `HUMAN_REVIEW_PENDING`. Stage 2 no está activado. No hubo integración en el landing oficial, mutación de Carolina, extracción del behavior core, promoción reusable, runtime ni despliegue.\n\nSiguiente acción única: revisión humana directa del HTML preservado.\n''',encoding='utf-8',newline='\n')
(ROOT/'projects/lab/continuity/START_PROMPT.md').write_text(f'''Continúa ChatGPT Prototype LAB reconstruyendo primero el estado desde `marcellusanthonson-ctrl/chatgpt-prototype-lab`, rama `main`, entrypoint `project-sources/chatgpt/START_HERE.md`; verifica el HEAD remoto mediante `VERIFY_LIVE_AT_USE` y sigue exactamente su orden de lectura.\n\nLa autorización 178 publicó Stage 1: el paquete completo del contador está preservado como `{PKG}` en `{BASE}`. El HTML directo de revisión es `{HTML}`. Stage 2 permanece condicional y no activado. No existe autorización para integrar en el landing oficial.\n''',encoding='utf-8',newline='\n')
ap='projects/lab/continuity/ATTACHMENT_MANIFEST.json';at=load(ap);at['manifest_id']='LAB-CONTINUITY-ATTACHMENTS-STATISTICS-COUNTER-SOURCE-PACKAGE-178-20260802';at['created_at']=STAMP
for x in [AUTH_P,BRIEF_P,EVD_P,PKG_P,DELTA,PEND]:add(at.setdefault('repository_sources_not_duplicated_as_attachments',[]),x)
at['authority_effect']='ONLY_CONDITIONAL_STAGE_2_AFTER_EXACT_HUMAN_DETERMINATION';save(ap,at)

for f in ROOT.rglob('*.json'):json.loads(f.read_text(encoding='utf-8'))
assert load(ep)['status']=='SOURCE_PACKAGE_PRESERVED_HUMAN_REVIEW_PENDING';assert load(PEND)['statistics_counter']['source_package_id']==PKG;assert load(cs)['next_authorized_action'].startswith('AUTHORIZATION_178_STAGE_2');assert load(rip)['counts']['authorizations']>=102;assert sha(HTML)==H_SHA
for x in ['scripts/_auth178_reconcile.py','.github/workflows/auth178-source-adoption.yml']:
    z=ROOT/x
    if z.exists():z.unlink()
print('AUTH178_RECONCILIATION_PASS')
