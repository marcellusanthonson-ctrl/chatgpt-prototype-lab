from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUTH = "AUTHORIZATION_LAB_STATISTICS_COUNTER_EXPERIMENT_SOURCE_ADOPTION_HUMAN_REVIEW_AND_CONDITIONAL_CLOSURE_178"
PKG = "CAROLINA-STATISTICS-MOTION-EXPERIMENT-001"
BASE = "foundation-library/motion-system/MOTION-SYSTEM-001/source-packages/CAROLINA-STATISTICS-MOTION-EXPERIMENT-001"
INTEGRATION = f"{BASE}/integration-source"
REVIEW = f"{INTEGRATION}/DIRECT_HUMAN_REVIEW.html"
DOM = f"{INTEGRATION}/SOURCE_STATS_SECTION.html"
MOTION = f"{INTEGRATION}/SOURCE_STATS_MOTION.js"
STYLES = f"{INTEGRATION}/SOURCE_STATS_STYLES.css"
PROVENANCE = f"{INTEGRATION}/SOURCE_EXCERPT_PROVENANCE.json"
INDEX = f"{BASE}/ARCHIVE_CONTENT_INDEX.json"
EXP_MANIFEST = f"{BASE}/expanded/statistics-motion-001/EXPERIMENT_MANIFEST.json"
SOURCE_INTEGRITY = f"{BASE}/expanded/statistics-motion-001/evidence/SOURCE_INTEGRITY_ATTEMPT_009.json"
ARCHIVE_INTEGRITY = f"{BASE}/expanded/statistics-motion-001/evidence/ARCHIVE_INTEGRITY_ATTEMPT_007.json"
VALIDATION_REPORT = f"{BASE}/expanded/statistics-motion-001/evidence/VALIDATION_REPORT_ATTEMPT_009.md"
FUNCTIONAL_RESULTS = f"{BASE}/expanded/statistics-motion-001/evidence/attempt006_functional_results.json"

AUTH_P = "projects/lab/authorizations/AUTHORIZATION_LAB_STATISTICS_COUNTER_EXPERIMENT_SOURCE_ADOPTION_HUMAN_REVIEW_AND_CONDITIONAL_CLOSURE_178.json"
BRIEF_P = "projects/lab/briefs/CODEX_STATISTICS_COUNTER_EXPERIMENT_SOURCE_ADOPTION_178_001.json"
EVD_P = "projects/lab/evidence/EVD-LAB-STATISTICS-COUNTER-SOURCE-PACKAGE-178.json"
PKG_P = f"{BASE}/SOURCE_PACKAGE_MANIFEST.json"
DELTA = "registry/deltas/statistics-counter-source-package-adoption-178.json"
PEND = "projects/lab/pending/PEND-LAB-043.json"

ARCHIVE_SHA = "8eecd53dc698d4587dfa882a5eabe701ec9a77a45bb9747d57f0cf5d68c876b0"
MONOLITH_SHA = "74274e55ff1c8b9edd849d433f12bf6ffe0abb00097872feb6bc7adde83b463e"
INDEX_SHA = "c44c2a763ca761e3c1be91f122abc90c76669c65c7a960abd81adbd50d2c8115"
DOM_SHA = "f9c192a24252d9685b7afc5099fa576f40037c7bbeb0cf00c1ad08d210ac3b39"
MOTION_SHA = "a387f76edbf4f5013f733b4d24d258185500f389e12637b65be6ad9171cf4e1e"
EXP_MANIFEST_SHA = "6ebc9d98e8ee6113b671136640994c861846241ca2b6d28a1298530e87fe0d0a"
SOURCE_INTEGRITY_SHA = "7d5e8a0f45fe0d881af09ca86c0b9565551f4b951482dc1a85c6650b1eb0ff67"
ARCHIVE_INTEGRITY_SHA = "96f29f1095e51ad49ec262ec22c6540e82be8d07a5a7d95ce1a54894314f5354"
VALIDATION_REPORT_SHA = "a2b830101590e7ff1d7e58486369fdc0630dcdb7f816ab8b4e8a245c5cdd167d"
FUNCTIONAL_RESULTS_SHA = "a3cdfb4a7f59a951edaba38218b34621748b938eaa8ca3cf35687ad49be2fea6"
STAMP = "2026-08-02T22:29:00-04:00"
DATE = "2026-08-02"


def load(path: str):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def save(path: str, obj) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(obj, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def add_unique(values: list, value) -> None:
    if value not in values:
        values.append(value)


def sha256(path: str) -> str:
    digest = hashlib.sha256()
    with (ROOT / path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bump_patch(version: str) -> str:
    parts = str(version).split(".")
    if parts and parts[-1].isdigit():
        parts[-1] = str(int(parts[-1]) + 1)
    return ".".join(parts)


def add_authorization_state(obj) -> bool:
    if isinstance(obj, dict):
        if "pend_047_exact_canonical_aggregate_reconciliation_and_closure_177" in obj:
            obj[
                "statistics_counter_experiment_source_adoption_human_review_and_conditional_closure_178"
            ] = "GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION"
            return True
        return any(add_authorization_state(value) for value in obj.values())
    if isinstance(obj, list):
        return any(add_authorization_state(value) for value in obj)
    return False


# Exact payload validation before any state mutation.
expected_hashes = {
    INDEX: INDEX_SHA,
    DOM: DOM_SHA,
    MOTION: MOTION_SHA,
    EXP_MANIFEST: EXP_MANIFEST_SHA,
    SOURCE_INTEGRITY: SOURCE_INTEGRITY_SHA,
    ARCHIVE_INTEGRITY: ARCHIVE_INTEGRITY_SHA,
    VALIDATION_REPORT: VALIDATION_REPORT_SHA,
    FUNCTIONAL_RESULTS: FUNCTIONAL_RESULTS_SHA,
}
for path, expected in expected_hashes.items():
    actual = sha256(path)
    if actual != expected:
        raise AssertionError(f"HASH_MISMATCH {path}: {actual} != {expected}")

archive_index = load(INDEX)
assert archive_index["archive_entry_count"] == 163
assert archive_index["extracted_file_count"] == 134
assert archive_index["archive_sha256"] == ARCHIVE_SHA
assert (ROOT / REVIEW).is_file()
assert (ROOT / STYLES).is_file()
assert load(PROVENANCE)["source_monolith"]["sha256"] == MONOLITH_SHA

# Authorization: Stage 1 published; Stage 2 remains conditional and untriggered.
auth = load(AUTH_P)
auth["status"] = "GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION"
auth["stage_1"]["status"] = "FUNCTIONAL_INTEGRATION_SOURCE_PRESERVED_AND_DIRECT_REVIEW_READY"
auth["stage_1"]["completed_at"] = STAMP
auth["stage_1"]["published_artifacts"] = [DOM, MOTION, STYLES, REVIEW, PROVENANCE, INDEX]
auth["stage_2"]["status"] = "CONDITIONALLY_AUTHORIZED_AWAITING_EXPLICIT_HUMAN_DETERMINATION"
auth["stage_2"]["triggered"] = False
auth["preservation"] = {
    "archive_sha256": ARCHIVE_SHA,
    "archive_entry_count": 163,
    "archive_content_index": INDEX,
    "archive_content_index_sha256": INDEX_SHA,
    "original_monolithic_html_sha256": MONOLITH_SHA,
    "original_monolithic_html_bytes": 1866483,
    "original_archive_and_monolith_repository_storage": "NOT_EMBEDDED_DUE_CONNECTOR_SINGLE_BLOB_TRUNCATION",
    "exact_dom_excerpt": {"path": DOM, "sha256": DOM_SHA},
    "exact_motion_script_excerpt": {"path": MOTION, "sha256": MOTION_SHA},
    "source_derived_styles": STYLES,
    "direct_review_harness": REVIEW,
    "source_mutation": "NONE",
}
auth["authority_effect_while_waiting"] = "NO_TECHNICAL_WRITE_UNTIL_EXACT_HUMAN_DETERMINATION_TRIGGERS_STAGE_2"
save(AUTH_P, auth)

brief = load(BRIEF_P)
brief["status"] = "STAGE_1_COMPLETE_STAGE_2_AWAITING_EXPLICIT_HUMAN_DETERMINATION"
brief["stage_1_result"] = "FUNCTIONAL_INTEGRATION_SOURCE_CAPSULE_AND_DIRECT_REVIEW_HARNESS_PUBLISHED"
brief["published_source"] = {
    "source_package_manifest": PKG_P,
    "archive_content_index": INDEX,
    "exact_dom_excerpt": DOM,
    "exact_motion_script_excerpt": MOTION,
    "source_derived_styles": STYLES,
    "direct_review_harness": REVIEW,
    "original_archive_sha256": ARCHIVE_SHA,
    "original_monolith_sha256": MONOLITH_SHA,
    "full_binary_embedding": "NOT_PERFORMED_DUE_CONNECTOR_SINGLE_BLOB_TRUNCATION",
}
brief["next_gate"] = "DIRECT_HUMAN_REVIEW_OF_PRESERVED_FUNCTIONAL_INTEGRATION_SOURCE"
save(BRIEF_P, brief)

evidence = load(EVD_P)
evidence["status"] = "FUNCTIONAL_INTEGRATION_SOURCE_PRESERVED_AWAITING_DIRECT_HUMAN_REVIEW"
evidence["repository_preservation"] = {
    "archive_content_index": {"path": INDEX, "sha256": INDEX_SHA},
    "exact_dom_excerpt": {"path": DOM, "sha256": DOM_SHA},
    "exact_motion_script_excerpt": {"path": MOTION, "sha256": MOTION_SHA},
    "source_derived_styles": STYLES,
    "direct_review_harness": REVIEW,
    "experiment_manifest": {"path": EXP_MANIFEST, "sha256": EXP_MANIFEST_SHA},
    "source_integrity_attempt_009": {"path": SOURCE_INTEGRITY, "sha256": SOURCE_INTEGRITY_SHA},
    "archive_integrity_attempt_007": {"path": ARCHIVE_INTEGRITY, "sha256": ARCHIVE_INTEGRITY_SHA},
    "validation_report_attempt_009": {"path": VALIDATION_REPORT, "sha256": VALIDATION_REPORT_SHA},
    "attempt006_functional_results": {"path": FUNCTIONAL_RESULTS, "sha256": FUNCTIONAL_RESULTS_SHA},
}
evidence["validation"]["repository_capsule_hashes"] = "PASS"
evidence["validation"]["original_archive_and_monolith_embedding"] = "NOT_PERFORMED_DUE_CONNECTOR_SINGLE_BLOB_TRUNCATION"
evidence["claim_boundary"] = (
    "THE_FUNCTIONAL_INTEGRATION_SOURCE_IS_PRESERVED_AS_EXACT_DOM_AND_MOTION_SCRIPT_EXCERPTS, "
    "SOURCE_DERIVED_STYLES, DIRECT_REVIEW_HARNESS, KEY_EVIDENCE, AND_COMPLETE_ARCHIVE_INDEX. "
    "THE_ORIGINAL_RAR_AND_FULL_MONOLITH_ARE_IDENTIFIED_BY_SHA256_BUT_NOT_EMBEDDED_AS_SINGLE_BLOBS. "
    "NO_LAB_HUMAN_APPROVAL_OR_PRODUCT_INTEGRATION_AUTHORITY_IS_CREATED."
)
save(EVD_P, evidence)

package = load(PKG_P)
package["status"] = "FUNCTIONAL_INTEGRATION_SOURCE_PRESERVED_AWAITING_DIRECT_HUMAN_REVIEW"
package["archive"].update(
    {
        "content_index": "ARCHIVE_CONTENT_INDEX.json",
        "content_index_sha256": INDEX_SHA,
        "repository_storage": "SHA256_AND_COMPLETE_CONTENT_INDEX",
        "binary_source": "NOT_EMBEDDED_DUE_CONNECTOR_SINGLE_BLOB_TRUNCATION",
    }
)
package.pop("direct_review_artifact", None)
package["original_monolith"] = {
    "path_in_archive": "statistics-motion-001/CAROLINA_MD_STATISTICS_MOTION_EXPERIMENT_001.html",
    "sha256": MONOLITH_SHA,
    "bytes": 1866483,
    "repository_storage": "NOT_EMBEDDED_DUE_CONNECTOR_SINGLE_BLOB_TRUNCATION",
}
package["functional_integration_source"] = {
    "exact_dom_excerpt": {"path": "integration-source/SOURCE_STATS_SECTION.html", "sha256": DOM_SHA},
    "exact_motion_script_excerpt": {"path": "integration-source/SOURCE_STATS_MOTION.js", "sha256": MOTION_SHA},
    "source_derived_styles": "integration-source/SOURCE_STATS_STYLES.css",
    "provenance": "integration-source/SOURCE_EXCERPT_PROVENANCE.json",
    "direct_review_harness": "integration-source/DIRECT_HUMAN_REVIEW.html",
    "status": "READY_FOR_DIRECT_HUMAN_REVIEW_AND_FUTURE_BOUNDED_PRODUCT_INTEGRATION",
}
package["preservation_policy"] = (
    "EXACT_DOM_AND_MOTION_SCRIPT_EXCERPTS_PLUS_SOURCE_DERIVED_STYLES_AND_KEY_EVIDENCE_ARE_REPOSITORY_ARTIFACTS; "
    "ORIGINAL_RAR_AND_FULL_MONOLITH_ARE_PRESERVED_BY_SHA256_AND_COMPLETE_CONTENT_INDEX."
)
package["next_gate"] = "DIRECT_HUMAN_REVIEW_OF_FUNCTIONAL_INTEGRATION_SOURCE"
save(PKG_P, package)

delta = load(DELTA)
delta["status"] = "STAGE_1_FUNCTIONAL_INTEGRATION_SOURCE_PUBLISHED_STAGE_2_CONDITIONAL"
delta["authorization"]["status"] = "GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION"
delta["source_package"].update(
    {
        "status": "FUNCTIONAL_INTEGRATION_SOURCE_PRESERVED_AWAITING_DIRECT_HUMAN_REVIEW",
        "archive_storage": "SHA256_AND_COMPLETE_CONTENT_INDEX",
        "direct_review_artifact": REVIEW,
        "exact_dom_excerpt": DOM,
        "exact_motion_script_excerpt": MOTION,
        "original_monolith_sha256": MONOLITH_SHA,
    }
)
delta["effect"]["status"] = "FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING"
delta["pending"]["status"] = "STATISTICS_COUNTER_FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING"
delta["authority_effect"] = "AUTHORIZATION_178_STAGE_2_CONDITIONAL_AWAITING_EXPLICIT_HUMAN_DETERMINATION"
save(DELTA, delta)

# Effect and motion-system manifests.
effect_path = "foundation-library/motion-system/MOTION-SYSTEM-001/effects/data/STATISTICS-COUNTER-STATIC-SUFFIX-001/MANIFEST.json"
effect = load(effect_path)
effect.update(
    {
        "schema_version": "1.1.0",
        "status": "FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING",
        "maximum_authorized_status": "FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING",
        "authorization_ref": AUTH,
        "canonical_reference_designation": False,
        "behavior_core_extraction": False,
        "product_integration_status": "NOT_AUTHORIZED_NOT_PERFORMED",
    }
)
effect["source_package"] = {
    "source_package_id": PKG,
    "manifest": PKG_P,
    "archive_sha256": ARCHIVE_SHA,
    "original_monolith_sha256": MONOLITH_SHA,
    "exact_dom_excerpt": DOM,
    "exact_motion_script_excerpt": MOTION,
    "direct_review_artifact": REVIEW,
    "status": "PRESERVED_AWAITING_DIRECT_HUMAN_REVIEW",
}
save(effect_path, effect)

system_path = "foundation-library/motion-system/MOTION-SYSTEM-001/MANIFEST.json"
system = load(system_path)
system.update(
    {
        "version": "0.2.1",
        "status": "FOUNDATION_PUBLISHED_ROADMAP_COMPLETE_STATISTICS_COUNTER_FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING",
        "latest_authorization_ref": AUTH,
        "maximum_initial_effect_status": "MIXED_ROADMAP_CANONICAL_REFERENCE_AND_BEHAVIOR_CORE_VALIDATED_STATISTICS_COUNTER_FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING",
    }
)
source_packages = system.setdefault("source_packages", [])
source_packages[:] = [entry for entry in source_packages if entry.get("source_package_id") != PKG]
source_packages.append(
    {
        "source_package_id": PKG,
        "effect_id": "STATISTICS-COUNTER-STATIC-SUFFIX-001",
        "path": BASE,
        "status": "FUNCTIONAL_INTEGRATION_SOURCE_PRESERVED_AWAITING_DIRECT_HUMAN_REVIEW",
        "archive_sha256": ARCHIVE_SHA,
        "original_monolith_sha256": MONOLITH_SHA,
        "exact_dom_excerpt": DOM,
        "exact_motion_script_excerpt": MOTION,
        "direct_review_artifact": REVIEW,
        "canonical_reference_designation": False,
        "product_integration": False,
    }
)
for path in [AUTH_P, EVD_P, PKG_P, DELTA]:
    add_unique(system.setdefault("source_refs", []), path)
system["remaining_gates"] = [
    "STATISTICS_COUNTER_DIRECT_HUMAN_REVIEW_OF_PRESERVED_FUNCTIONAL_SOURCE",
    "SEPARATE_NEUTRAL_ADAPTATION_AUTHORIZATION_IF_DESIRED",
    "SEPARATE_REUSABLE_PROMOTION_AUTHORIZATION",
    "SEPARATE_PRODUCT_INTEGRATION_AUTHORIZATION",
    "REMAINING_LIBRARY_POPULATION_IN_BOUNDED_BATCHES",
]
save(system_path, system)

motion_registry_path = "foundation-library/motion-system/MOTION-SYSTEM-001/MOTION_EFFECTS_REGISTRY.json"
motion_registry = load(motion_registry_path)
motion_registry["schema_version"] = "1.2.0"
motion_registry["updated_at"] = DATE
for record in motion_registry["records"]:
    if record.get("effect_id") == "STATISTICS-COUNTER-STATIC-SUFFIX-001":
        record.update(
            {
                "status": "FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING",
                "source_package": PKG_P,
                "exact_dom_excerpt": DOM,
                "exact_motion_script_excerpt": MOTION,
                "direct_review_artifact": REVIEW,
                "canonical_reference_designated": False,
                "behavior_core_extracted": False,
                "reusable_promotion": False,
                "product_integration": False,
            }
        )
        break
else:
    raise AssertionError("MISSING_COUNTER_REGISTRY_RECORD")
save(motion_registry_path, motion_registry)

# Pending item and aggregate.
pend = load(PEND)
pend["status"] = "STATISTICS_COUNTER_FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING"
for action in [
    "PRESERVE_STATISTICS_COUNTER_ARCHIVE_PROVENANCE_AND_COMPLETE_CONTENT_INDEX_IN_LAB",
    "PRESERVE_EXACT_STATISTICS_COUNTER_DOM_AND_MOTION_SCRIPT_EXCERPTS",
    "PUBLISH_STATISTICS_COUNTER_DIRECT_REVIEW_HARNESS",
]:
    add_unique(pend.setdefault("completed_actions", []), action)
pend["required_actions"] = [
    "HUMAN_REVIEW_PRESERVED_STATISTICS_COUNTER_FUNCTIONAL_INTEGRATION_SOURCE",
    "SEPARATELY_AUTHORIZE_NEUTRAL_ADAPTATION_IF_DESIRED",
    "PROMOTE_REVISE_OR_REJECT_OTHER_INITIAL_EFFECTS",
    "IMPLEMENT_INDUSTRY_EFFECTS_IN_BOUNDED_BATCHES",
    "AUTHORIZE_REUSABLE_PROMOTION_SEPARATELY",
    "AUTHORIZE_PROJECT_INTEGRATIONS_SEPARATELY",
]
pend["statistics_counter"] = {
    "effect_id": "STATISTICS-COUNTER-STATIC-SUFFIX-001",
    "status": "FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING",
    "source_package_id": PKG,
    "source_package_manifest": PKG_P,
    "archive_sha256": ARCHIVE_SHA,
    "original_monolith_sha256": MONOLITH_SHA,
    "exact_dom_excerpt": DOM,
    "exact_motion_script_excerpt": MOTION,
    "direct_review_artifact": REVIEW,
    "next_single_gate": "DIRECT_HUMAN_REVIEW_OF_PRESERVED_FUNCTIONAL_INTEGRATION_SOURCE",
}
pend["current_authority"] = "AUTHORIZATION_178_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_EXPLICIT_HUMAN_DETERMINATION"
for path in [AUTH_P, EVD_P, PKG_P, DELTA]:
    add_unique(pend.setdefault("source_refs", []), path)
save(PEND, pend)

pending_aggregate_path = "projects/lab/PENDING.json"
pending_aggregate = load(pending_aggregate_path)
for index, record in enumerate(pending_aggregate["records"]):
    if record.get("id") == "PEND-LAB-043":
        pending_aggregate["records"][index] = pend
        break
else:
    raise AssertionError("MISSING_PEND_LAB_043_AGGREGATE")
pending_aggregate["updated_at"] = DATE
save(pending_aggregate_path, pending_aggregate)

# Canonical current state.
current_path = "CURRENT_STATE.json"
current = load(current_path)
current["version"] = bump_patch(current["version"])
current["updated_at"] = DATE
canonical_model = current.setdefault("canonical_model", {})
canonical_model["motion_statistics_counter_source_package_178"] = PKG_P
canonical_model["motion_statistics_counter_authorization_178"] = AUTH_P
canonical_model["motion_statistics_counter_evidence_178"] = EVD_P
motion_state = canonical_model["motion_system_foundation"]
motion_state["status"] = "ROADMAP_COMPLETE_STATISTICS_COUNTER_FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING"
motion_state["latest_authorization"] = AUTH
motion_state["statistics_counter_001"] = {
    "effect_id": "STATISTICS-COUNTER-STATIC-SUFFIX-001",
    "status": "FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING",
    "source_package_id": PKG,
    "source_package_manifest": PKG_P,
    "archive_sha256": ARCHIVE_SHA,
    "original_monolith_sha256": MONOLITH_SHA,
    "exact_dom_excerpt": DOM,
    "exact_motion_script_excerpt": MOTION,
    "direct_review_artifact": REVIEW,
    "canonical_reference_designation": False,
    "behavior_core_extraction": False,
    "product_integration": False,
}
motion_state["next_gate"] = "DIRECT_HUMAN_REVIEW_OF_PRESERVED_FUNCTIONAL_INTEGRATION_SOURCE"
add_authorization_state(current)
current["next_authorized_action"] = "NONE_UNTIL_EXACT_HUMAN_DETERMINATION_TRIGGERS_AUTHORIZATION_178_STAGE_2"
current["next_recommended_transition"] = "DIRECT_HUMAN_REVIEW_OF_PRESERVED_STATISTICS_COUNTER_FUNCTIONAL_INTEGRATION_SOURCE"
current["motion_statistics_counter_source_adoption_178"] = {
    "authorization": AUTH,
    "authorization_status": "GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION",
    "source_package_id": PKG,
    "source_package_status": "FUNCTIONAL_INTEGRATION_SOURCE_PRESERVED_AWAITING_DIRECT_HUMAN_REVIEW",
    "archive_sha256": ARCHIVE_SHA,
    "original_monolith_sha256": MONOLITH_SHA,
    "original_archive_and_monolith_embedding": "NOT_PERFORMED_DUE_CONNECTOR_SINGLE_BLOB_TRUNCATION",
    "exact_dom_excerpt": DOM,
    "exact_motion_script_excerpt": MOTION,
    "direct_review_artifact": REVIEW,
    "stage_2_triggered": False,
    "official_landing_integration": "NOT_AUTHORIZED_NOT_PERFORMED",
    "runtime_effect": "NONE",
    "product_effect": "NONE",
}
save(current_path, current)

project_state_path = "projects/lab/PROJECT_STATE.json"
project_state = load(project_state_path)
project_state["updated_at"] = DATE
for path in [AUTH_P, BRIEF_P, EVD_P, PKG_P, DELTA]:
    add_unique(project_state.setdefault("source_refs", []), path)
project_state["motion_statistics_counter_source_adoption_178"] = {
    "authorization_status": "GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION",
    "source_package_id": PKG,
    "source_package_manifest": PKG_P,
    "effect_status": "FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING",
    "direct_review_artifact": REVIEW,
    "next_gate": "DIRECT_HUMAN_REVIEW_OF_PRESERVED_FUNCTIONAL_INTEGRATION_SOURCE",
}
save(project_state_path, project_state)

# Registry discovery.
registry_index_path = "registry/index.json"
registry_index = load(registry_index_path)
registry_index["updated_at"] = DATE
counts = registry_index["counts"]
counts["authorizations"] = max(counts.get("authorizations", 0), 102)
counts["evidence"] = max(counts.get("evidence", 0), 84)
counts["source_packages"] = max(counts.get("source_packages", 0), 3)
registries = registry_index["registries"]
for key in ["authorization_deltas", "evidence_deltas", "current_state_deltas"]:
    add_unique(registries.setdefault(key, []), DELTA)
add_unique(registries.setdefault("source_package_records", []), PKG_P)
save(registry_index_path, registry_index)

# Continuity.
continuity_path = "projects/lab/continuity/CURRENT_CONTINUITY.json"
continuity = load(continuity_path)
continuity["continuity_id"] = "LAB-CONTINUITY-STATISTICS-COUNTER-FUNCTIONAL-SOURCE-178-20260802"
continuity["status"] = "STATISTICS_COUNTER_FUNCTIONAL_SOURCE_PRESERVED_DIRECT_HUMAN_REVIEW_PENDING_PRIORITY_INTEGRATIONS_PHASE_1_PRESERVED"
continuity["created_at"] = STAMP
continuity["global_state"]["active_execution_authority"] = "NONE_UNTIL_AUTHORIZATION_178_STAGE_2_TRIGGERED_BY_EXACT_HUMAN_DETERMINATION"
continuity["authorization_178"] = {
    "id": AUTH,
    "status": "GRANTED_STAGE_1_PUBLISHED_STAGE_2_CONDITIONALLY_AUTHORIZED_AWAITING_HUMAN_DETERMINATION",
    "stage_1": "FUNCTIONAL_INTEGRATION_SOURCE_PUBLISHED",
    "stage_2": "AWAITING_EXPLICIT_HUMAN_DETERMINATION",
    "triggered": False,
}
continuity["statistics_counter_source_package"] = {
    "source_package_id": PKG,
    "status": "FUNCTIONAL_INTEGRATION_SOURCE_PRESERVED_AWAITING_DIRECT_HUMAN_REVIEW",
    "manifest": PKG_P,
    "archive_sha256": ARCHIVE_SHA,
    "original_monolith_sha256": MONOLITH_SHA,
    "exact_dom_excerpt": DOM,
    "exact_motion_script_excerpt": MOTION,
    "direct_review_artifact": REVIEW,
    "original_archive_and_monolith_embedding": "NOT_PERFORMED_DUE_CONNECTOR_SINGLE_BLOB_TRUNCATION",
}
continuity["next_action"] = {
    "single": "DIRECT_HUMAN_REVIEW_OF_PRESERVED_STATISTICS_COUNTER_FUNCTIONAL_INTEGRATION_SOURCE",
    "repository_write_before_human_determination": False,
}
continuity["authority_effect"] = "ONLY_CONDITIONAL_STAGE_2_AFTER_EXACT_HUMAN_DETERMINATION"
for path in [AUTH_P, BRIEF_P, EVD_P, PKG_P, DELTA, PEND]:
    add_unique(continuity.setdefault("required_reading_order", []), path)
save(continuity_path, continuity)

(ROOT / "projects/lab/continuity/CURRENT_CONTINUITY.md").write_text(
    f"""# Continuidad LAB — fuente funcional del contador preservada\n\n"
    f"La autorización `{AUTH}` publicó Stage 1. La fuente funcional necesaria para integrar el contador quedó preservada como `{PKG}`.\n\n"
    f"Revisión directa: `{REVIEW}`\n\n"
    f"Se preservaron literalmente el DOM (`{DOM}`) y el motor de movimiento (`{MOTION}`), junto con estilos trazables, evidencia clave y el índice completo de 163 entradas del RAR. El RAR original tiene SHA-256 `{ARCHIVE_SHA}` y el monolito original SHA-256 `{MONOLITH_SHA}`. Ambos se identifican por hash; no se incrustaron como blobs únicos porque el conector truncó el payload.\n\n"
    "El contador permanece `HUMAN_REVIEW_PENDING`. Stage 2 no está activado. No hubo integración en el landing oficial, mutación de Carolina, designación canónica del contador, extracción del behavior core, promoción reusable, runtime ni despliegue.\n\n"
    "Siguiente acción única: revisión humana directa del capsule funcional preservado.\n",
    encoding="utf-8",
    newline="\n",
)

(ROOT / "projects/lab/continuity/START_PROMPT.md").write_text(
    f"""Continúa ChatGPT Prototype LAB reconstruyendo primero el estado desde `marcellusanthonson-ctrl/chatgpt-prototype-lab`, rama `main`, entrypoint `project-sources/chatgpt/START_HERE.md`; verifica el HEAD remoto mediante `VERIFY_LIVE_AT_USE` y sigue exactamente su orden de lectura.\n\n"
    f"La autorización 178 publicó Stage 1: la fuente funcional del contador está preservada como `{PKG}` en `{BASE}`. La revisión directa está en `{REVIEW}`. El DOM y el motor de movimiento son extractos literales del experimento; el RAR y el monolito originales se preservan por SHA-256 e índice completo, no como blobs únicos. Stage 2 permanece condicional y no activado. No existe autorización para integrar en el landing oficial.\n",
    encoding="utf-8",
    newline="\n",
)

attachment_path = "projects/lab/continuity/ATTACHMENT_MANIFEST.json"
attachment = load(attachment_path)
attachment["manifest_id"] = "LAB-CONTINUITY-ATTACHMENTS-STATISTICS-COUNTER-FUNCTIONAL-SOURCE-178-20260802"
attachment["created_at"] = STAMP
for path in [AUTH_P, BRIEF_P, EVD_P, PKG_P, DELTA, PEND, REVIEW, DOM, MOTION, PROVENANCE]:
    add_unique(attachment.setdefault("repository_sources_not_duplicated_as_attachments", []), path)
attachment["authority_effect"] = "ONLY_CONDITIONAL_STAGE_2_AFTER_EXACT_HUMAN_DETERMINATION"
save(attachment_path, attachment)

# Full JSON parse and state checks.
for file in ROOT.rglob("*.json"):
    json.loads(file.read_text(encoding="utf-8"))

assert load(effect_path)["status"] == "FUNCTIONAL_SOURCE_PRESERVED_HUMAN_REVIEW_PENDING"
assert load(PEND)["statistics_counter"]["source_package_id"] == PKG
assert load(current_path)["next_authorized_action"].startswith("NONE_UNTIL_EXACT_HUMAN_DETERMINATION")
assert load(registry_index_path)["counts"]["authorizations"] >= 102
assert sha256(DOM) == DOM_SHA
assert sha256(MOTION) == MOTION_SHA
assert sha256(INDEX) == INDEX_SHA

# Remove all execution scaffolding from the final tree.
for path in ["scripts/_auth178_reconcile.py", ".github/workflows/auth178-source-adoption.yml"]:
    target = ROOT / path
    if target.exists():
        target.unlink()
payload = ROOT / ".auth178-payload"
if payload.exists():
    for child in sorted(payload.rglob("*"), reverse=True):
        if child.is_file() or child.is_symlink():
            child.unlink()
        elif child.is_dir():
            child.rmdir()
    payload.rmdir()

print("AUTH178_STAGE1_FUNCTIONAL_SOURCE_RECONCILIATION_PASS")
